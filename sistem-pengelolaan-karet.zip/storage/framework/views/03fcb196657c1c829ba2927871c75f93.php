

<?php $__env->startSection('title', 'Data Gaji'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Data Gaji</h1>
        <div class="d-flex justify-content-end">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Data Gaji</li>
                </ol>
            </nav>
        </div>
        <!-- DataTales -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
            <!-- <a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahDataModal">Tambah</a> -->
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="20px">No.</th>
                                <th>Karyawan</th>
                                <th>Tanggal Gaji</th>
                                <th>Kategori</th>
                                <th>Jumlah Gaji</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $panen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Auth::user()->role == 'karyawan' && $item->karyawan->id != Auth::user()->karyawan->id): ?>
                                    <?php continue; ?>
                                <?php endif; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->karyawan->nama); ?></td>
                                    <td><?php echo e(formatToDate($item->tanggal_panen)); ?></td>
                                    <td><?php echo e($item->harga->kategori); ?></td>
                                    <td><?php echo e(formatToRupiah($item->total_gaji)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('gaji.slip', $item->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-print fa-sm fa-fw mr-2"></i>Print</a>
                                        <?php if(Auth::user()->role == 'admin'): ?>
                                        <form action="<?php echo e(route('gaji.destroy', $item->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')"><i class="fas fa-trash fa-sm fa-fw mr-2"></i>Hapus</button>
                                        </form>  
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- Script untuk menampilkan foto -->
    <script>
        function hitungGaji() {
            var total_hasil_kg = document.getElementById('total_hasil_kg').value;
            var harga_per_kg = document.getElementById('harga_per_kg').value;
            var gaji = total_hasil_kg * harga_per_kg;
            document.getElementById('gaji').value = gaji;
        }

        document.getElementById('total_hasil_kg').addEventListener('change', hitungGaji);
        document.getElementById('harga_per_kg').addEventListener('change', hitungGaji);
    </script>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('assets/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.js')); ?> "></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('assets/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Teknik Informatika\Skripsi\Sistem\sistem-pengelolaan-karet\resources\views/gaji/index.blade.php ENDPATH**/ ?>