


<div class="modal fade text-left" id="showModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="showModalLabel<?php echo e($item->id); ?>" data-bs-backdrop="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="showModalLabel">Detail Data Karyawan</h4>
                <button type="button" class="close" data-bs-dismiss="modal"
                    aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="mt-3 mb-4">
                            <img src="<?php echo e(asset('images/' . $item->foto)); ?>" alt="<?php echo e($item->nama); ?>"
                                class="rounded-circle img-fluid" style="width: 100px;" />
                        </div>
                        <h4 class="mb-2"><?php echo e($item->nama); ?></h4>
                        <p class="mb-4"><?php echo e($item->alamat); ?></p>
                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <td>Nama</td>
                                        <td>:</td>
                                        <td><?php echo e($item->nama); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Alamat</td>
                                        <td>:</td>
                                        <td><?php echo e($item->alamat); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Umur</td>
                                        <td>:</td>
                                        <td><?php echo e($item->umur); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Kelamin</td>
                                        <td>:</td>
                                        <td><?php echo e($item->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>No. Telp</td>
                                        <td>:</td>
                                        <td><?php echo e($item->no_telp); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\Kuliah\Teknik Informatika\Skripsi\Sistem\sistem-pengelolaan-karet\resources\views/karyawan/show.blade.php ENDPATH**/ ?>