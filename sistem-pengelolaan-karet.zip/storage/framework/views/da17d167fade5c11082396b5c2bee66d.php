

<?php $__env->startSection('title', 'Pengajuan Cuti'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Edit Pengajuan Cuti</h1>
        <div class="d-flex justify-content-end">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('cuti.index')); ?>">Data Cuti</a></li>
                    <li class = "breadcrumb-item active" aria-current="page">Edit Pengajuan Cuti</li>
                </ol>
            </nav>
        </div>
    <div class="card ">
        <div class="card-body">
            <form action="<?php echo e(route('cuti.update', $cuti->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group mandatory">
                    <label class="form-label" for="data_karyawan_id">Nama Karyawan</label>
                    <select class="form-control form-control-sm" id="data_karyawan_id" name="data_karyawan_id">
                        <option value="">-- Pilih Karyawan --</option>
                        <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($cuti->data_karyawan_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group mandatory col-md-6">
                        <label class="form-label" for="tanggal_mulai">Tanggal Mulai Cuti</label>
                        <input type="date" class="form-control" id="tanggal_mulai" name="tanggal_mulai" value="<?php echo e($cuti->tanggal_mulai); ?>" required>
                    </div>
                    <div class="form-group mandatory col-md-6">
                        <label class="form-label" for="tanggal_selesai">Tanggal Selesai Cuti</label>
                        <input type="date" class="form-control" id="tanggal_selesai" name="tanggal_selesai" value="<?php echo e($cuti->tanggal_selesai); ?>" required>
                    </div>
                </div>
                <div class="form-group mandatory">
                    <label class="form-label" for="keterangan">Keterangan</label>
                    <textarea class="form-control" id="keterangan" name="keterangan" rows="3" required><?php echo e($cuti->keterangan); ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Teknik Informatika\Skripsi\Sistem\sistem-pengelolaan-karet\resources\views/cuti/edit.blade.php ENDPATH**/ ?>