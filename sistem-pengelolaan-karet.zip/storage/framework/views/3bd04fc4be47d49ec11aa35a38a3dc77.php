<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Success!</strong> <?php echo e(session('success')); ?>

</div>
<?php elseif(session('info')): ?>
<div class="alert alert-info alert-dismissible">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Info!</strong> <?php echo e(session('info')); ?>

</div>
<?php elseif(session('warning')): ?>
<div class="alert alert-warning alert-dismissible">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Warning!</strong> <?php echo e(session('warning')); ?>

</div>
<?php elseif(session('error')): ?>
<div class="alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Error!</strong> <?php echo e(session('error')); ?>

</div>
<?php endif; ?><?php /**PATH D:\Kuliah\Teknik Informatika\Skripsi\Sistem\sistem-pengelolaan-karet\resources\views/layouts/alert.blade.php ENDPATH**/ ?>