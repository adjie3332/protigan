

<?php $__env->startSection('title', 'Tambah Data Karyawan'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">
        <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Tambah Data Karyawan</h1>
        <div class="d-flex justify-content-end">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('karyawan.index')); ?>">Data Karyawan</a></li>
                    <li class = "breadcrumb-item active" aria-current="page">Tambah Data Karyawan</li>
                </ol>
            </nav>
        </div>
    <div class="card ">
        <div class="card-body">
            <form action="<?php echo e(route('karyawan.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mandatory">
                    <label class="form-label" for="nama">Nama</label>
                    <input type="text" class="form-control form-control-sm" id="nama" name="nama" placeholder="Masukkan Nama">
                </div>
                <div class="form-group mandatory">
                    <label class="form-label" for="alamat">Alamat</label>
                    <textarea class="form-control form-control-sm" id="alamat" rows="3" name="alamat" placeholder="Masukkan Alamat"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group mandatory col-md-6">
                        <label class="form-label" for="tanggal_lahir">Tanggal Lahir</label>
                        <input type="date" class="form-control form-control-sm" id="tanggal_lahir" name="tanggal_lahir">
                    </div>
                    <div class="form-group mandatory col-md-6">
                        <label class="form-label" for="jenis_kelamin">Jenis Kelamin</label>
                        <select class="form-control form-control-sm" id="jenis_kelamin" name="jenis_kelamin">
                            <option value="">-- Pilih Jenis Kelamin --</option>
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group mandatory col-md-6">
                        <label class="form-label" for="no_telp">No. Telp</label>
                        <input type="text" class="form-control form-control-sm" id="no_telp" name="no_telp" placeholder="Masukkan No. Telp">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="foto">Foto</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="foto" name="foto">
                            <label class="custom-file-label" for="foto">Pilih Foto</label>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for='username'>Username</label>
                        <input type="text" class="form-control form-control-sm" id="username" name="username" placeholder="Masukkan Username">
                    </div>
                    <div class="form-group col-md-6">
                        <label for='email'>Email</label>
                        <input type="email" class="form-control form-control-sm" id="email" name="email" placeholder="Masukkan Email">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for='password'>Password</label>
                        <input type="password" class="form-control form-control-sm" id="password" name="password" placeholder="Masukkan Password">
                    </div>
                    <div class="form-group col-md-6">
                        <label for='role'>Role</label>
                        <select class="form-control form-control-sm" id="role" name="role">
                            <option value="">-- Pilih Role --</option>
                            <option value="admin">Admin</option>
                            <option value="karyawan">Karyawan</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#foto').on('change', function() {
            // Ambil nama file foto
            let fileName = $(this).val().split('\\').pop();
            // Ubah label foto
            $(this).next('.custom-file-label').addClass("selected").html(fileName);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Teknik Informatika\Skripsi\Sistem\sistem-pengelolaan-karet\resources\views/karyawan/create.blade.php ENDPATH**/ ?>