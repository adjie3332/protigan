

<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Profile</h1>

        <div class="d-flex justify-content-end">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Profile</li>
                </ol>
            </nav>
        </div>
        <!-- Profile -->
        <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <?php if(Auth::user()->karyawan->foto === null): ?>
                        <img src="<?php echo e(asset('assets/img/undraw_profile.svg')); ?>" alt="Admin" class="rounded-circle" width="150">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/'.Auth::user()->karyawan->foto)); ?>" alt="Admin" class="rounded-circle" width="150">
                    <?php endif; ?>
                    <div class="mt-3">
                      <h4><?php echo e(Auth::user()->username); ?></h4>
                      <p class="text-secondary mb-1"><?php echo e(Auth::user()->role); ?></p>
                      <p class="text-muted font-size-sm"><?php echo e(Auth::user()->karyawan->alamat); ?></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Nama</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                        <?php echo e(Auth::user()->karyawan->nama); ?>

                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Email</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                        <?php echo e(Auth::user()->email); ?>

                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">No. Telp</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                        <?php echo e(Auth::user()->karyawan->no_telepon); ?>

                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Alamat</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                        <?php echo e(Auth::user()->karyawan->alamat); ?>

                    </div>
                  </div>
                  <hr>
                <div class="row">
                    <div class="col-sm-3">
                    <h6 class="mb-0">Umur</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                        <?php echo e(Auth::user()->karyawan->umur); ?>

                    </div>
                </div>
                <hr>
                  <div class="row">
                    <div class="col-sm-12">
                      <a href="<?php echo e(route('profile.edit', Auth::user()->id)); ?>" class="btn btn-info btn-sm">Edit Profile</a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Change Password</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('profile.change-password', Auth::user()->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group mandatory">
                                <label class="form-label" for="password">Password</label>
                                <input type="password" class="form-control form-control-sm" id="password" name="password" placeholder="Masukkan Password">
                            </div>
                            <div class="form-group mandatory">
                                <label class="form-label" for="new_password">New Password</label>
                                <input type="password" class="form-control form-control-sm" id="new_password" name="new_password" placeholder="Masukkan New Password">
                            </div>
                        <button type="submit" class="btn btn-success btn-sm">Change Password</button>
                        </form>
                    </div>
                </div>
              </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Teknik Informatika\Skripsi\Sistem\sistem-pengelolaan-karet\resources\views/auth/profile.blade.php ENDPATH**/ ?>