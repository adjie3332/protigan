


<div class="modal" id="showModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="showModalLabel<?php echo e($item->id); ?>" data-bs-backdrop="false" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="showModalLabel">Detail Data Karyawan</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="mt-3 mb-4">
                            <?php if($item->foto): ?>
                                <img src="<?php echo e(asset('images/' . $item->foto)); ?>" alt="<?php echo e($item->nama); ?>" class="rounded-circle img-fluid" style="width: 200px;" />
                            <?php else: ?>      
                                <img src="<?php echo e(asset('assets/img/undraw_profile.svg')); ?>" alt="Admin" class="rounded-circle" width="150">
                            <?php endif; ?>
                        </div>
                        <h4 class="mb-2"><?php echo e($item->nama); ?></h4>
                        <p class="mb-4"><?php echo e($item->alamat); ?></p>
                        <div class="row text-start">
                            <div class="col-6">
                                <p class="mb-2">Umur</p>
                                <h5 class="mb-4"><?php echo e($item->umur); ?></h5>
                            </div>
                            <div class="col-6">
                                <p class="mb-2">Jenis Kelamin</p>
                                <h5 class="mb-4"><?php echo e($item->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></h5>
                            </div>
                        </div>
                        <div class="row text-start">
                            <div class="col-6">
                                <p class="mb-2">E-mail</p>
                                <h5 class="mb-4"><?php echo e($item->user->email); ?></h5>
                            </div>
                            <div class="col-6">
                                <p class="mb-2">No. Telp</p>
                                <h5 class="mb-4"><?php echo e($item->no_telepon); ?></h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\Kuliah\Teknik Informatika\Skripsi\Sistem\sistem-pengelolaan-karet\resources\views/Karyawan/show.blade.php ENDPATH**/ ?>