

<?php $__env->startSection('title', 'Tambah Data Panen'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css" integrity="sha512-xmGTNt20S0t62wHLmQec2DauG9T+owP9e6VU8GigI0anN7OXLip9i7IwEhelasml2osdxX71XcYm6BQunTQeQg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .bootstrap-tagsinput .tag {
            margin-right: 2px;
            color: white !important;
            background-color: #00acc1;
            border-radius: 4px;
            padding: 0.2rem;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Tambah Data Panen</h1>
    <div class="d-flex justify-content-end">
        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('panen.index')); ?>">Data Panen</a></li>
                <li class="breadcrumb-item active" aria-current="page">Tambah Data Panen</li>
            </ol>
        </nav>
    </div>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('panen.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mandatory">
                    <label class="form-label" for="id_karyawan">Nama Karyawan</label>
                    <select class="form-control form-control-sm" id="id_karyawan" name="data_karyawan_id">
                        <option value="">-- Pilih Nama Karyawan --</option>
                        <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group mandatory">
                    <label class="form-label" for="harga_id">Harga Karet</label>
                    <select class="form-control form-control-sm" id="harga_id" name="harga_karet_id">
                        <option value="">-- Pilih Harga Karet --</option>
                        <?php $__currentLoopData = $harga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->kategori); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group mandatory">
                    <label class="form-label" for="tanggal">Tanggal</label>
                    <input type="date" class="form-control form-control-sm" id="tanggal" name="tanggal_panen" placeholder="Masukkan Tanggal">
                </div>
                <div class="form-group mandatory">
                    <label class="form-label" for="hasil_kg">Hasil (Kg)</label>
                    <input type="text" class="form-control form-control-sm" id="hasil_kg" name="hasil_kg[]" placeholder="Masukkan Hasil (Kg)" data-role="tagsinput">
                </div>
                <div class="form-group">
                    <label for="total_hasil_kg">Total Hasil (Kg)</label>
                    <input type="text" class="form-control form-control-sm" id="total_hasil_kg" name="total_hasil_kg" placeholder="Total Hasil (Kg)" readonly>
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Page level plugins -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.min.js" integrity="sha512-9UR1ynHntZdqHnwXKTaOm1s6V9fExqejKvg5XMawEMToW4sSw+3jtLrYfZPijvnwnnE8Uol1O9BcAskoxgec+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function () {
        var hasilKgInput = $('#hasil_kg');
        var totalHasilKgInput = $('#total_hasil_kg');

        hasilKgInput.on('itemAdded itemRemoved', function () {
            var hasilKgArray = hasilKgInput.tagsinput('items').map(Number); // Convert to numbers
            var totalHasilKg = hasilKgArray.reduce((acc, val) => acc + val, 0); // Calculate sum
            totalHasilKgInput.val(totalHasilKg);
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Teknik Informatika\Skripsi\Sistem\sistem-pengelolaan-karet\resources\views/panen/create.blade.php ENDPATH**/ ?>