

<?php $__env->startSection('title', 'Data Cuti'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Data Cuti</h1>
        <div class="d-flex justify-content-end">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Data Cuti</li>
                </ol>
            </nav>
        </div>
        <!-- DataTales -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
            <a href="<?php echo e(route('cuti.create')); ?>" class="btn btn-primary btn-sm">Tambah</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Karyawan</th>
                                <th>Tanggal Mulai</th>
                                <th>Tanggal Selesai</th>
                                <th>Total Hari</th>
                                <th>Keterangan</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $cuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->karyawan->nama); ?></td>
                                <td><?php echo e($item->tanggal_mulai); ?></td>
                                <td><?php echo e($item->tanggal_selesai); ?></td>
                                <td><?php echo e($item->total_hari); ?></td>
                                <td><?php echo e($item->keterangan); ?></td>
                                <td>
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <?php if($item->status == 'pending'): ?>
                                    <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#tambahDataModal<?php echo e($item->id); ?>"><?php echo e($item->status); ?></a>
                                    <?php elseif($item->status == 'disetujui'): ?>
                                        <span class="btn btn-success"><?php echo e($item->status); ?></span>
                                    <?php elseif($item->status == 'ditolak'): ?>
                                        <span class="btn btn-danger"><?php echo e($item->status); ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($item->status == 'pending'): ?>
                                        <span class="btn btn-warning"><?php echo e($item->status); ?></span>
                                    <?php elseif($item->status == 'disetujui'): ?>
                                        <span class="btn btn-success"><?php echo e($item->status); ?></span>
                                    <?php elseif($item->status == 'ditolak'): ?>
                                        <span class="btn btn-danger"><?php echo e($item->status); ?></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('cuti.edit', $item->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-pen fa-sm fa-fw mr-2"></i>Edit</a>
                                    <form action="<?php echo e(route('cuti.destroy', $item->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm"><i class="fas fa-trash fa-sm fa-fw mr-2"></i>Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <!-- Modal Update Status -->
                            <div class="modal fade" id="tambahDataModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="tambahDataModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="tambahDataModalLabel">Validasi Pengajuan Cuti</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('cuti.update-status', ['id' => $item->id])); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <button type="submit" class="btn btn-success" name="status" value="disetujui">Disetujui</button>
                                                <button type="submit" class="btn btn-danger" name="status" value="ditolak">Ditolak</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Modal -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('assets/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.js')); ?> "></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('assets/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Teknik Informatika\Skripsi\Sistem\sistem-pengelolaan-karet\resources\views/cuti/index.blade.php ENDPATH**/ ?>